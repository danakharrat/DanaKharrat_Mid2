package com.example.danakharrat_mid2;


import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class FirstActivity extends AppCompatActivity {

    String url = "https://api.openweathermap.org/data/2.5/weather?q=london&appid=6ca149ef3a0256693d52233bbf9f4768&units=metric";
    ImageView weatherBackground;
    TextView temperature, humidity,reservation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonDate=(Button) findViewById(R.id.btnDate);
        reservation =(TextView) findViewById(R.id.result);
        temperature = findViewById(R.id.temperature);
        humidity = findViewById(R.id.humidity);

        buttonDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(FirstActivity.this,d,c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        weather(url);
    }

    Calendar c=Calendar.getInstance();
    DateFormat fmtDate=DateFormat.getDateInstance();
    DatePickerDialog.OnDateSetListener d = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            c.set(Calendar.YEAR, year);
            c.set(Calendar.MONTH, month);
            c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            reservation.setText("Your reservation is set for "+fmtDate.format(c.getTime()));
        }};

    public void weather(String url){
        @SuppressLint("SetTextI18n") JsonObjectRequest jsonObj = new JsonObjectRequest(Request.Method.GET, url, null, response -> {
            Log.d("Dana", "Response Received");
            Log.d("Dana", response.toString());
            try {
                JSONObject jsonMain = response.getJSONObject("main");
                JSONObject jsonSys = response.getJSONObject("sys");

                double temp = jsonMain.getDouble("temp");
                Log.d("Leena","temp=" + temp);
                temperature.setText(String.valueOf(temp)+"°C");

                double feels = jsonMain.getDouble("feels_like");

                double humid = jsonMain.getDouble("humidity");
                Log.d("Dana","humidity=" + feels);
                humidity.setText("Humidity: "+String.valueOf(humid));


                JSONArray jsonArray = response.getJSONArray("weather");
                for (int i=0; i<jsonArray.length();i++){
                    Log.d("Dana-array",jsonArray.getString(i));
                    JSONObject oneObject = jsonArray.getJSONObject(i);
                    String weather =
                            oneObject.getString("main");
                    Log.d("Dana-w",weather);

                }
            }
            catch (JSONException e){
                e.printStackTrace();
                Log.e("Receive Error", e.toString());
            }
        }, error -> Log.d("Dana", "Error Retrieving URL"));
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(jsonObj);
    }
}